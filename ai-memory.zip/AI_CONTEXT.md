# AI_CONTEXT — PX Phone

Last reviewed: 2026-10-24. Basis: static reading of `px-phone-v20.html` (nothing was executed). Legend: **[V]** verified in code, **[I]** inferred, **[?]** unknown.

## 1. What it is
- **[V]** "PX Phone": an Arabic (RTL) 3D phone-repair-shop tycoon game for mobile and desktop browsers, built as a **single HTML file** (`px-phone-v20.html`, ~5,300 lines, ~290 KB).
- **[V]** The player repairs customers' phones at a workbench, earns money and XP, buys shop upgrades, reads books for skills, explores a street with other shops, and can expand the world.
- **[?]** Repository URL, repo layout, README content, deployment target, and whether other files exist besides this HTML.

## 2. Tech stack [V]
- Plain HTML/CSS/JavaScript, `'use strict'`, one inline `<script>`; no build step seen.
- **three.js r128** from `cdnjs.cloudflare.com` (the only external script). Font: Tajawal (Google Fonts).
- Canvas `#scene` (WebGL) plus DOM panels for UI; the close-up repair view is SVG/DOM, not WebGL.
- Persistence: `localStorage`.

## 3. Architecture of the file [V]
The script is organised by `// ===== Section =====` banners, then **layered version patches** appended in order (`v2` … `v11`, then `v20`). Later layers wrap or override earlier functions (e.g. `updateLighting = function () { _ulE(); ... }`). Rule of thumb: **new features are added as a new layer at the end, not by rewriting the base.**
- Base: Timing/limits constants → layout boxes → content (TOOLS, PARTS, FAULTS, MODELS, UPGRADES, BOOKS, TASKS) → state → repair jobs → economy → save format → renderer/scene → shop, bedroom, street, traffic → buy zones → bench → customers → movement/camera/lighting → HUD → sound → panels → reading cutscene → store/ledger/tasks/phone app → settings → save slots → menus → day end → interactive close-up repair view → main loop → input → start.
- Patches: v2 fullscreen/profile/requests/shops · v3 zoom+first person, sky · v4 shop upgrades, workers, new device types · v5 skyline, celebration · v6–v7 eureka scene, dragon, fireworks · v8 camera, library, ledger, tap guard · v9 bedroom door, side buildings, shop expansion · v10 world expansion at level 200 (PX company, mega wholesale market) · "Level 500: end of the game" · v11 level-10 tools/repairs, furniture placement · **v20 reference-video look**: HUD extras, wheel of fortune, perks (starter/VIP/boost), floor chevrons, pastel skyline.
- Lines `/*@pure:begin*/ … /*@pure:end*/` (about lines 412–886) wrap the pure game logic. **[?]** Purpose (probably extraction for tests) is not documented.
- The v20 patch creates extra panels (`#pWheel`, `#pPerk`) from JS "so the old markup stays untouched".

## 4. Key rules and numbers [V]
- Day runs 08:00→24:00 (shop closes 21:00); start money 200; level = 1 + floor(xp/100); `BASE_ALLOWED_MISTAKES = 4`; price range 10–200 step 5; daily gift $50; `END_LEVEL = 500`, `WORLD_LEVEL = 200`.
- Faults: screen, battery, port, camera, speaker, buttons, boot. Models: Nova X1, Aster S, Kilo Mini (price multipliers 1.0/1.25/0.85).
- v20 economy: `incomeMult` = 1 + "stay %" (rises over play time, capped at 30%) + 10% VIP, ×2 while boost is active. Wheel: one free spin per day, otherwise $30. VIP costs $500, boost $150 (5 min), starter pack free once.
- Save: `SAVE_VERSION = 3`; slots under `pxphone.v3.slot*` with `.bak` fallback; autosave writes slot 0; settings key `pxphone.settings.v1`; extra keys `pxExt`, `pxWorld`, `px10`. **Changing the save shape requires a version/migration plan.**
- Quality auto-selects `low` on low-end/mobile devices (`LOW_END`).

## 5. Run / test
- **[V]** No build: open the HTML in a browser (needs internet for three.js and fonts unless vendored).
- **[?]** No test files, test command, or CI were provided. Do not claim tests exist.

## 6. Conventions to respect
- Arabic UI text, RTL layout; touch-first controls (joystick, `touch-action:none`).
- Keep the single-file delivery unless the owner decides otherwise.
- Prefer additive patches; keep old markup/IDs working.

## 7. Known limitations / open questions
See `PROGRESS.md` and `NEXT_STEPS.md`. Related docs: `AI_HANDOFF.md`, `AI_INSTRUCTIONS.md`, `DECISIONS.md`, `SESSION_LOG.md`.
