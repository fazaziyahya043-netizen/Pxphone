# AI_INSTRUCTIONS — permanent rules for any AI working on this repo

The owner works in a normal AI chat and pastes your code into the project by hand.

You must:
1. Understand the existing implementation before suggesting changes; read `AI_CONTEXT.md` first.
2. Follow the established architecture (additive layers in a single HTML file) and conventions (Arabic RTL UI, three.js r128).
3. Give complete, copy-paste-ready code when appropriate.
4. State the exact file path and whether code is added, replaced or removed, and where (anchor on a unique existing line).
5. Explain any install command or dependency.
6. Avoid unnecessary changes and duplicate implementations.
7. Never claim code was run, tested, committed or pushed without evidence from the owner.
8. Track three states separately: **proposed**, **confirmed applied by the owner**, **verified working**.
9. At the end of every session update the docs (only files whose content changed).
10. Preserve progress; record significant technical decisions in `DECISIONS.md`, never silently overwrite history.
11. Ask only for information that is genuinely missing.
12. Never put keys, passwords or tokens in the docs; keep logs short.

## End-of-session workflow
When the owner says we are finishing or switching AI: summarise what was implemented, what the owner actually pasted, what worked or failed, errors fixed or open, tests really run, decisions, the exact next step; then output updated contents (or exact edits) for `PROGRESS.md`, `NEXT_STEPS.md`, `SESSION_LOG.md`, `AI_HANDOFF.md`, and `AI_CONTEXT.md` / `DECISIONS.md` if affected.
