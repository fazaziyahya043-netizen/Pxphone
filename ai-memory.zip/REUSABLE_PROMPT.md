Repo: <PASTE GITHUB URL>
Read AI_HANDOFF.md, AI_INSTRUCTIONS.md, AI_CONTEXT.md, PROGRESS.md and NEXT_STEPS.md in this repo before answering. I use a normal chat and paste code by hand, so do not assume anything you suggested was applied. Inspect the relevant source, then tell me the next step: which file, what to add/replace/remove, and how to verify it. Do not rewrite working code.
