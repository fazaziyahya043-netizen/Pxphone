## AI memory system

This repo keeps its own context so any AI assistant can continue the work after a switch.

- [AI_HANDOFF.md](AI_HANDOFF.md) — short brief to paste into a new AI chat
- [AI_CONTEXT.md](AI_CONTEXT.md) — architecture and rules
- [PROGRESS.md](PROGRESS.md) — latest verified state
- [NEXT_STEPS.md](NEXT_STEPS.md) — prioritized next tasks
- [DECISIONS.md](DECISIONS.md) — technical decisions
- [SESSION_LOG.md](SESSION_LOG.md) — session history
- [AI_INSTRUCTIONS.md](AI_INSTRUCTIONS.md) — permanent rules for assistants

**Switching assistants:** paste the repo URL and the reusable prompt, then ask the new AI to read these files. Before stopping, ask the current AI to update them and commit.
