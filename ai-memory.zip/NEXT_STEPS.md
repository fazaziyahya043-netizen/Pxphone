# NEXT_STEPS — PX Phone

Only the immediate task is detailed; the rest is deliberately short.

## 1. Establish the baseline (do first)
- **Task:** Owner opens `px-phone-v20.html` on the target device, plays through: new game → one repair → day end → save → continue, and reports what works or breaks (paste console errors if any).
- **Why:** No run evidence exists, so no later change can be called safe.
- **Prerequisites:** the file, a browser (mobile or desktop).
- **Files:** `px-phone-v20.html`.
- **Expected result:** a short pass/fail list recorded in `PROGRESS.md` (Last known working state, Tests performed).
- **Verify:** owner's report; browser console with no red errors.

## 2. Define the goal for the next version
- **Task:** Owner states the single feature or bug for v21.
- **Why:** The file is large and layered; one focused change per session limits regressions.
- **Prerequisites:** task 1.
- **Verify:** goal written in `NEXT_STEPS.md`.

## 3. (Optional, only if wanted) Add a minimal smoke test
- **Why:** The code has `@pure` markers around logic, which may allow extracting it for Node tests. **[?]**
- **Verify:** a command the owner runs and shares output of.

Do not add tasks without the owner's confirmation or evidence from the code.
