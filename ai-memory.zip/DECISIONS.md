# DECISIONS — PX Phone

Decisions below are **inferred from the code** unless marked otherwise; the owner should confirm or correct them.

| # | Decision | Context / reason | Alternatives | Consequences | Status |
|---|----------|------------------|--------------|--------------|--------|
| 1 | Single HTML file, no build step | Easy to deliver and run (owner works from phone/Termux, per earlier notes) [I] | Multi-file project, bundler | File is ~5,300 lines; edits must be precise | Active [I] |
| 2 | three.js r128 via CDN | Simple include; r128 API is relied on [I] | Newer three.js, vendored copy | Needs internet; do not use APIs newer than r128 | Active [V] |
| 3 | Layered version patches appended at the end (v2…v20) | Add features without touching working base [V comment in v20: "old markup stays untouched"] | Refactor into modules | Later layers override earlier functions; order matters | Active [V] |
| 4 | Save format `SAVE_VERSION = 3`, slots + `.bak` fallback | Protect against corrupt saves [V] | Single slot | Shape changes need migration/version bump | Active [V] |
| 5 | Auto quality: low on mobile/low-end | Performance on phones [V] | Fixed quality | Visual differences between devices | Active [V] |
| 6 | v20 look follows a reference video (HUD, wheel, perks, pastel skyline) | Owner's request via earlier work [I] | — | Reference video is not in the repo | Active [I] |
| 7 | Arabic-first RTL UI | Target players [V] | Multilingual | New text must be Arabic | Active [V] |

Add new rows when a decision changes; mark old ones `superseded`, never delete.
